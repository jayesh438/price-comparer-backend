document.getElementById("searchBtn").addEventListener("click", async () => {
  const query = document.getElementById("productInput").value;
  const response = await fetch("https://your-api.onrender.com/compare-prices", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ productName: query })
  });

  const data = await response.json();
  const resultsDiv = document.getElementById("results");
  resultsDiv.innerHTML = "";

  let lowestPrice = Number.MAX_VALUE;
  let lowestSite = "";

  data.results.forEach(({ site, title, price, link }) => {
    let priceVal = parseInt(price?.replace(/[^0-9]/g, ""));
    if (priceVal && priceVal < lowestPrice) {
      lowestPrice = priceVal;
      lowestSite = site;
    }
  });

  data.results.forEach(({ site, title, price, link }) => {
    const entry = document.createElement("div");
    entry.innerHTML = `<strong>${site}</strong>: ${title}<br>Price: ₹${price}<br><a href="${link}" target="_blank">View Product</a><br><br>`;
    if (site === lowestSite) entry.style.background = "#d4edda";
    resultsDiv.appendChild(entry);
  });
});