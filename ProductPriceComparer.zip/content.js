function getProductTitle() {
  const hostname = window.location.hostname;

  if (hostname.includes("amazon")) {
    return document.getElementById("productTitle")?.innerText.trim();
  }
  if (hostname.includes("flipkart")) {
    return document.querySelector("span.B_NuCI")?.innerText.trim();
  }
  if (hostname.includes("meesho")) {
    return document.querySelector("h1")?.innerText.trim();
  }
  return null;
}